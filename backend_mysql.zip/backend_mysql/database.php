<?php

$host = "localhost";
$dbname = "ecomerce_website";
$username = "root";
$password = "";
$connection = mysqli_connect($host, $username, $password, $dbname);



return $connection;